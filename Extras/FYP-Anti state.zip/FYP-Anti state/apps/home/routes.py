# -*- encoding: utf-8 -*-
"""
Copyright (c) 2019 - present AppSeed.us
"""

from apps.home import blueprint
from flask import render_template, request
from flask_login import login_required
from jinja2 import TemplateNotFound
from werkzeug.utils import secure_filename
from unicodedata import digit
import pickle
import re
import numpy as np
import pandas as pd
from nltk.corpus import stopwords
import string
from flask import Flask, flash, request, redirect, render_template




@blueprint.route('/index')
@login_required
def index():

    return render_template('home/index.html', segment='index')


@blueprint.route('/<template>')
@login_required
def route_template(template):

    try:

        if not template.endswith('.html'):
            template += '.html'

        # Detect the current page
        segment = get_segment(request)

        # Serve the file (if exists) from app/templates/home/FILE.html
        return render_template("home/" + template, segment=segment)

    except TemplateNotFound:
        return render_template('home/page-404.html'), 404

    except:
        return render_template('home/page-500.html'), 500


# Helper - Extract current page name from request
def get_segment(request):

    try:

        segment = request.path.split('/')[-1]

        if segment == '':
            segment = 'index'

        return segment

    except:
        return None



sentiment_analyzer_model = pickle.load(open('my_model.pkl', 'rb'))


def cleanText(x):
    x = x.encode('ascii', 'ignore').decode()  # remove emojis
    x = re.sub(r'https*\S+', '', x)  # remove urls
    x = re.sub(r'@\S+', '', x)  # remove mentions
    x = re.sub(r'#\S+', '', x)  # remove hashtags
    x = re.sub(r'\'w+', '', x)
    return x


def preporocess(tweet):
    tweet = [t for t in tweet if t not in string.digits]  # removing digits
    tweet = ''.join(tweet)
    tweet = [t for t in tweet if t not in string.punctuation]  # removing punctuations
    return ''.join(tweet)


@blueprint.route('/s_t', methods=["GET", "POST"])
def s_t():
    if request.method == "POST":
        f = request.files['file']
        limit = int(request.form['limit'])
        f.save(secure_filename(f.filename))
        flash('success file uploaded ')
        # f.load(f.filename)
        column_names = ['No','tweet','username','id']
        data = pd.read_csv(f.filename,names=column_names)
        # data['tweet']=data['tweet'].apply(cleanText)  # cleaning the text using cleanText function ,
        # removing hashes , mentions emojis and urls etc
        data['tweet'] = data['tweet'].apply(preporocess)  # preprocessing the tweets removing stopwords , punctuations , digits
        data['tweet'] = data['tweet'].apply(lambda x: x.strip())  # removing spaces in the begining of the tweet
        data['tweet'] = data['tweet'].dropna()

        # return f.filename + "file" + str(len(data)) + "<p>" + str( data['tweet'][:10]) + "</p>"
        # preds=[]
        # pred.append(sentiment_analyzer_model.predict([data['tweet'][i]]))
        # for i in range(limit):

        preds = sentiment_analyzer_model.predict(data['tweet'][:limit])
        # result={'tweet':data['tweet'][:limit] ,'prediction':pred}
        result = { }
        for i, j,k,l,a in zip(data['tweet'][:limit],data['No'][:limit],preds,data['username'][:limit],data['id'][:limit]):
            if j == 1.0:
                result[i] = (l,k,a,'Anti State')
            else:
                result[i] = (l,k,a,'Not Anti State')

        return render_template("result.html", result=result)





